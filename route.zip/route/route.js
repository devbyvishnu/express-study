import express from "express";
import { userLogin,userSign } from "./controller";

const router = express.Router();

// Define the routes
router.get("/login", userLogin);
router.get("/signup", userSign);
// Add more routes as needed
// Export the router
export default router;