export const userLogin = (req, res) => {
    res.send('User login page');
};

export const userSign = (req, res) => {
    res.send('User sign up page');
};